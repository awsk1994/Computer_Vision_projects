f = open("demofile3.txt", "w")
f.write("Woops! I have deleted the content!1\n")
f.write("Woops! I have deleted the content!2\n")

f.close()
