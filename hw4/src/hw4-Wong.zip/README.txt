bat_data_loader.py: run alpha beta filter on bat dataset
cell_data_loader.py: run alpha beta filter on cell dataset
